# Security Policy

## Supported Versions

The latest version of rive-next is the only version that is supported, as it is the only version that is being actively developed.

## Reporting a Vulnerability

You can contact the rive-next maintainers to report a vulnerability:

- Report the vulnerability in the [rive-next Issues](https://github.com/Developabile/rive-next/issues)
