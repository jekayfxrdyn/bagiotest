import CategorywisePage from "@/components/CategorywisePage";

const Tv = () => {
  return <CategorywisePage categoryDiv="tv" categoryPage="kdrama" />;
};

export default Tv;
